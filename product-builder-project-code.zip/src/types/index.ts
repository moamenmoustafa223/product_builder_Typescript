export type ProductNameTypes = "title" | "description" | "imageURL" | "price";
